
/*++
Copyright (c) 2015 Microsoft Corporation

--*/


#include "util/timeout.h"
#include "util/trace.h"

#ifdef _WINDOWS

#include <windows.h>

void tst_timeout() {
}

#else
void tst_timeout() {
}

#endif
