/*++
Copyright (c) 2006 Microsoft Corporation

Module Name:

    tst_region.cpp

Abstract:

    Test region memory allocator.

Author:

    Leonardo de Moura (leonardo) 2006-09-14.

Revision History:

--*/
#include<stdlib.h>
#include "util/region.h"

static void tst1() {
    // TODO
}

void tst_region() {
    tst1();
}

