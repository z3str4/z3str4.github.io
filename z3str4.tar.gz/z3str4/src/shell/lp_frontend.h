/*
  Copyright (c) 2013 Microsoft Corporation. All rights reserved.

  Author: Lev Nachmanson
*/
#pragma once
unsigned read_mps_file(char const * mps_file_name);
